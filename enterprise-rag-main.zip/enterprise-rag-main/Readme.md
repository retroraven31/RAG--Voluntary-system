# Enterprise RAG System  

Welcome to Jacob’s Enterprise RAG (Retrieval-Augmented Generation) System repository. This project enables enterprises to derive meaningful insights from their data using Language Model (LLM) queries.  

---Repository Overview-----  

### Directory Structure  

- **db/**: Includes Docker configurations (`docker-compose.yml`), setup scripts (`reset.py`, `setup.py`), and database utilities.  
- **files/**: Contains sample data files such as `sample.csv`.  
- **frontend/**: Houses a Streamlit-based user interface (`stream-ui.py`) for interactive data visualization.  
- **notebooks/**: Jupyter notebooks for experimenting with RAG functionalities (`rag.ipynb`, `table_rag.ipynb`).  
- **server/**: Backend logic responsible for LLM-driven query retrieval and data processing.  
  - **chains/**: Modules implementing various RAG pipelines (`chain_utils.py`, `qa.py`, `simple_rag.py`, etc.).  
  - **configs/**: Configuration settings (`settings.py`).  
  - **db/**: Database-related utility scripts (`db_utils.py`).  
  - **models/**: Components facilitating data processing (`csv_agent.py`, `embeddings.py`, `llm.py`).  
  - **services/**: Services handling document processing (`document_processing.py`).  

## Setup and Execution  

To run the project locally, follow these steps:  

1. **Clone the repository:**  
   ```bash
   git clone https://github.com/Jacob/repository-name
   cd repository-name
   ```  

2. **Install required dependencies:**  
   ```bash
   pip install -r requirements.txt
   ```  

3. **Start the frontend interface:**  
   ```bash
   cd frontend
   streamlit run stream-ui.py
   ```  

4. **Initialize and launch the backend:**  

   a. Start the database services:  
   ```bash
   cd ../db
   docker-compose up -d
   python -m setup
   ```  

   b. Configure environment variables (e.g., Google API key):  
   ```bash
   export GOOGLE_API_KEY=your_api_key_here
   ```  

   c. Run the backend server:  
   ```bash
   cd ../server
   python -m server.main
   ```  

## Additional Information  

- **Scalability & Optimization:** The system is designed to be both scalable and efficient, utilizing Streamlit for an intuitive user interface and Docker for managing backend services.  